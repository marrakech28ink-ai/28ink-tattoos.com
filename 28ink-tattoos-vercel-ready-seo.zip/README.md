# 28ink-tattoos Marrakech

Site vitrine statique livré prêt pour Vercel. La racine contient les pages françaises; leurs versions anglaises et italiennes sont publiées en HTML complet dans `en/` et `it/`. Le sélecteur traduit immédiatement la page en place, sans rechargement et sans perdre le défilement; l’URL et les métadonnées se synchronisent avec la langue choisie. Les liens internes conservent cette langue.

## Aperçu local

Ouvrir `index.html` dans un navigateur ou servir le dossier avec n’importe quel hébergement statique. Les chemins des médias, CSS et scripts sont relatifs à la racine du domaine.

## Vercel

Le dépôt n’a pas de dépendances ni de commande de build. Importer le dossier dans un projet Vercel statique, laisser la commande de build vide et utiliser la racine (`.`) comme répertoire de sortie. Voir [`vercel-deploy.md`](vercel-deploy.md) pour le guide détaillé. Le fichier `vercel.json` configure la mise en cache des images et des en-têtes de sécurité.

## SEO et recherche IA

`robots.txt` autorise l’exploration publique et référence le sitemap; `sitemap.xml` liste les pages françaises, anglaises et italiennes avec leurs alternates hreflang. Les pages définissent des URL canoniques, des métadonnées sociales et des titres/descriptions localisés. `llms.txt` et `llms-full.txt` résument les informations publiques du studio.

## Médias

Les trois visuels originaux du carrousel sont dans `assets/hero-tattoo-*.jpg`. Les autres médias du portfolio fournis dans l’archive d’origine sont conservés.
