/* ============================================================
   28ink-tattoos MARRAKECH — Internationalisation (i18n)
   Languages: FR (default) | EN | IT
   ============================================================ */

'use strict';

const translations = {

  /* ─── FRANÇAIS ─────────────────────────────────────────── */
  fr: {
    /* NAV */
    nav_home:          'Accueil',
    nav_services:      'Services',
    nav_gallery:       'Réalisations',
    nav_about:         'À Propos',
    nav_blog:          'Blog',
    nav_faq:           'FAQ',
    nav_contact:       'Contact',
    nav_book:          'Prendre RDV',

    /* HERO */
    hero_kicker:       'Salon de Tatouage — Marrakech, Maroc',
    hero_title_1:      '28ink-tattoos',
    hero_title_2:      'Marrakech',
    hero_subtitle:     'Art permanent, tradition marocaine. Le premier studio de tatouage haut de gamme de Marrakech.',
    hero_btn_gallery:  'Voir les Réalisations',
    hero_btn_book:     'Réserver maintenant',

    /* TICKER */
    ticker_1: 'Tatouage Fin', ticker_2: 'Minimaliste', ticker_3: 'Géométrique',
    ticker_4: 'Floral', ticker_5: 'Réaliste', ticker_6: 'Oriental',
    ticker_7: 'Script', ticker_8: 'Blackwork', ticker_9: 'Marrakech',

    /* ABOUT SECTION */
    about_label:       'Notre Histoire',
    about_title:       'L\'art du tatouage au cœur de la Médina',
    about_desc:        '28ink-tattoos est studio de tatouage à Marrakech, fondé par Adam Mehdi. Nous fusionnons l\'art contemporain et l\'héritage culturel marocain pour créer des œuvres permanentes d\'exception.',
    about_since:       'Depuis 2018',
    about_stat1_num:   '01', about_stat1_lbl: 'Studio · Marrakech',
    about_stat2_num:   '3',    about_stat2_lbl: 'Artistes Experts',
    about_stat3_num:   '98%',  about_stat3_lbl: 'Satisfaction Client',

    /* STYLES SECTION */
    styles_label:      'Nos Spécialités',
    styles_title:      'Chaque style, une signature',
    style1_title:      'Fin & Minimaliste', style1_sub: 'Fineline · Délicat',
    style2_title:      'Géométrique',       style2_sub: 'Symétrie · Précision',
    style3_title:      'Floral & Botanique',style3_sub: 'Nature · Élégance',
    style4_title:      'Script & Lettrage', style4_sub: 'Écriture · Sens',
    style5_title:      'Blackwork',         style5_sub: 'Contraste · Impact',
    style6_title:      'Oriental & Arabesque', style6_sub: 'Culture · Tradition',

    /* REEL */
    reel_label:        'En action',
    reel_title:        'Le processus créatif',
    reel_desc:         'Découvrez nos tatoueurs à l\'œuvre. Chaque geste est précis, chaque tracé est définitif.',

    /* STATS */
    stat1_num: '01', stat1_lbl: 'Création sur mesure',
    stat2_num: '6',   stat2_lbl: 'Années d\'Expérience',
    stat3_num: '100', stat3_lbl: 'Motifs Exclusifs',
    stat4_num: '3',   stat4_lbl: 'Styles du portfolio',

    /* BOOK CTA */
    book_label:    'Réservation',
    book_title:    'Prêt(e) à porter votre histoire sur peau ?',
    book_desc:     'Écrivez-nous sur WhatsApp pour discuter de votre projet et des prochaines étapes.',
    book_btn:      'Réserver sur WhatsApp',
    book_or:       'ou',
    book_form:     'Formulaire de Contact',

    /* FOOTER */
    footer_tagline: 'Studio de tatouage et créations personnalisées à Marrakech, Maroc.',
    footer_nav:       'Navigation',
    footer_services:  'Services',
    footer_contact:   'Contact',
    footer_addr: '40100 Marrakech, Maroc',
        footer_phone:     '+212 069 372 1314',
    footer_email:     'amourkira216@gmail.com',
    footer_copy:      '© 2026 28ink-tattoos Marrakech. Tous droits réservés.',
    footer_legal_privacy: 'Confidentialité',
    footer_legal_terms:   'Mentions légales',

    /* SERVICES PAGE */
    services_hero_label: 'Nos Prestations',
    services_hero_title: 'Des services taillés sur mesure',
    services_hero_desc:  'Du premier tatouage au projet le plus ambitieux, nous vous accompagnons à chaque étape.',
    services: [
      { icon:'needle', title:'Tatouage Fineline', desc:'Traits ultrafins, détails ciselés. Notre spécialité maison pour des compositions délicates et intemporelles.' },
      { icon:'geometry', title:'Tatouage Géométrique', desc:'Symétries parfaites, mandalas, lignes mathématiques. Une rigueur artistique que nos clients adorent.' },
      { icon:'flower', title:'Tatouage Floral & Botanique', desc:'Roses, feuilles, compositions florales — naturelles et élégantes sur toutes les zones du corps.' },
      { icon:'text', title:'Script & Lettrage', desc:'Citations, prénoms, calligraphie arabe ou latine. Chaque lettre portée avec intention.' },
      { icon:'blackwork', title:'Blackwork & Dotwork', desc:'Contrastes puissants, remplissages en pointillés. Un style fort pour une expression radicale.' },
      { icon:'cover', title:'Retouche & Cover-up', desc:'Refonte ou correction d\'un ancien tatouage. Nos artistes analysent et proposent la meilleure solution.' },
      { icon:'consult', title:'Échange sur le projet', desc:'Échangez avec nos artistes sur votre projet. Design personnalisé inclus avant chaque séance.' },
      { icon:'aftercare', title:'Soins & Suivi', desc:'Nous vous fournissons tous les conseils post-tatouage pour une cicatrisation optimale.' }
    ],

    /* REALISATIONS PAGE */
    gallery_hero_label: 'Notre Portfolio',
    gallery_hero_title: 'Chaque tatouage, une œuvre',
    gallery_hero_desc:  'Explorez l\'ensemble de nos réalisations. Images et vidéos de process incluses.',
    gallery_filter_all:   'Tout',
    gallery_filter_photo: 'Photos',
    gallery_filter_video: 'Vidéos',
    gallery_filter_fineline:    'Fineline',
    gallery_filter_geometric:   'Géométrique',
    gallery_filter_floral:      'Floral',
    gallery_filter_blackwork:   'Blackwork',

    /* CONTACT */
    contact_hero_label: 'Contact',
    contact_hero_title: 'Let\'s talk about your project',
    contact_hero_desc:  'Fill in the form or contact us directly on WhatsApp.',
    contact_name:    'Full name',
    contact_email:   'Email',
    contact_phone:   'Phone (optional)',
    contact_style:   'Desired style',
    contact_message: 'Describe your project',
    contact_send:    'Send via WhatsApp',
    contact_wa_direct: 'WhatsApp Direct',
    contact_address: 'Address',
    contact_hours:   'Opening hours',
        contact_sunday:  'Closed on Sundays',
    select_style:    'Select a style',

    /* FAQ */
    faq_hero_label: 'FAQ',
    faq_hero_title: 'Everything you need to know',
    faq_hero_desc:  'Clear answers about tattooing, booking and aftercare.',
    faqs: [
      { q:'How can I contact the studio?', a:'Message the studio on WhatsApp at +212 069 372 1314 or use the contact form.' },
      { q:'How can I discuss my tattoo project?', a:'Message us on WhatsApp with your idea, approximate placement and size. The studio will get back to you directly to discuss the details.' },
      { q:'Is your equipment sterilised and safe?', a:'Absolutely. We use single-use needles exclusively. Our equipment is sterilised to international standards. Hygiene is our top priority.' },
      { q:'How long does a tattoo take to heal?', a:'Surface healing takes 2–3 weeks. Deep healing takes 3–6 months. We provide a full aftercare guide after every session.' },
      { q:'Can I bring my own design?', a:'You can share a drawing or reference images to explain your idea.' },
      { q:'Do you do touch-ups and cover-ups?', a:'Yes. We analyse each case and propose the best technical solution. A prior consultation is needed for complex cover-ups.' },
      { q:'Is the initial consultation free?', a:'Yes, consultation is completely free. Discuss your project with our artists with no commitment.' },
      { q:'Do you tattoo tourists visiting Marrakech?', a:'Yes, we welcome all clients, tourists and residents alike. Simply book in advance to secure your slot.' },
      { q:'What is the exact address of the studio?', a:'Our studio is located in the Medina of Marrakech. Contact us on WhatsApp for the precise address and directions.' },
      { q:'Do you offer temporary tattoos?', a:'No, we specialise exclusively in professional-quality permanent tattooing.' }
    ],

    /* BLOG */
    blog_hero_label: 'Blog & News',
    blog_hero_title: 'Art, Culture & Ink',
    blog_hero_desc:  'Tips, inspiration and behind-the-scenes from 28ink-tattoos Marrakech studio.',

    /* CHATBOT */
    chatbot_name:    '28ink-tattoos Assistant',
    chatbot_status:  'Online now',
    chatbot_welcome: 'Hello! 👋 I\'m the 28ink-tattoos Marrakech assistant. How can I help you?',
    chatbot_price:   'Message the studio on WhatsApp with your idea and preferred placement to discuss your project.',
    chatbot_book:    'To book, contact us on WhatsApp: +212 069 372 1314 or via our contact form.',
    chatbot_hygiene: 'We use single-use needles and our equipment is sterilised to international standards.',
    chatbot_heist:   'Our studio is in the Medina of Marrakech. Contact us for the exact address.',
    chatbot_fallback:'I don\'t have that specific information. Contact us directly on WhatsApp for an immediate reply!',
    chatbot_wa:      'Message on WhatsApp',
    chatbot_quick_price:    '💬 My project',
    chatbot_quick_book:     '📅 Book',
    chatbot_quick_hygiene:  '🧼 Hygiene',
    chatbot_quick_location: '📍 Location',
    chatbot_placeholder: 'Ask your question...',
  },

  en: {
    /* NAV */
    nav_home:          'Home',
    nav_services:      'Services',
    nav_gallery:       'Gallery',
    nav_about:         'About',
    nav_blog:          'Blog',
    nav_faq:           'FAQ',
    nav_contact:       'Contact',
    nav_book:          'Book Now',

    /* HERO */
    hero_kicker:       'Tattoo Studio — Marrakech, Morocco',
    hero_title_1:      '28INK',
    hero_title_2:      'Marrakech',
    hero_subtitle:     'Discover tattoo styles and designs from 28ink-tattoos in Marrakech.',
    hero_btn_gallery:  'View Gallery',
    hero_btn_book:     'Book Now',

    /* TICKER */
    ticker_1: 'Fine Line', ticker_2: 'Minimalist', ticker_3: 'Geometric',
    ticker_4: 'Floral', ticker_5: 'Realistic', ticker_6: 'Oriental',
    ticker_7: 'Script', ticker_8: 'Blackwork', ticker_9: 'Marrakech',

    /* ABOUT */
    about_label:       'Our Story',
    about_title:       'The art of tattooing in the heart of the Medina',
    about_desc:        '28INK is Marrakech\'s first premium tattoo studio, founded by Adam Mehdi. We blend contemporary art with Moroccan cultural heritage to create exceptional permanent works.',
    about_since:       'Since 2018',
    about_stat1_num:   '01', about_stat1_lbl: 'Marrakech studio',
    about_stat2_num:   '3',    about_stat2_lbl: 'Expert Artists',
    about_stat3_num:   '98%',  about_stat3_lbl: 'Satisfaction Rate',

    /* STYLES */
    styles_label:      'Our Specialties',
    styles_title:      'Every style, a signature',
    style1_title:      'Fine & Minimalist',   style1_sub: 'Fineline · Delicate',
    style2_title:      'Geometric',           style2_sub: 'Symmetry · Precision',
    style3_title:      'Floral & Botanical',  style3_sub: 'Nature · Elegance',
    style4_title:      'Script & Lettering',  style4_sub: 'Writing · Meaning',
    style5_title:      'Blackwork',           style5_sub: 'Contrast · Impact',
    style6_title:      'Oriental & Arabesque',style6_sub: 'Culture · Tradition',

    /* REEL */
    reel_label:  'In action',
    reel_title:  'The creative process',
    reel_desc:   'Watch our tattoo artists at work. Every stroke is precise, every line is permanent.',

    /* STATS */
    stat1_num: '600', stat1_lbl: 'Tattoos Done',
    stat2_num: '6',   stat2_lbl: 'Years of Experience',
    stat3_num: '100', stat3_lbl: 'Exclusive Designs',
    stat4_num: '3',   stat4_lbl: 'Certified Artists',

    /* BOOK CTA */
    book_label: 'Booking',
    book_title: 'Ready to wear your story on skin?',
    book_desc:  'Message the studio on WhatsApp to discuss your project and the next steps.',
    book_btn:   'Book via WhatsApp',
    book_or:    'or',
    book_form:  'Contact Form',

    /* FOOTER */
    footer_tagline: 'Tattoo studio and custom designs in Marrakech, Morocco.',
    footer_nav:       'Navigation',
    footer_services:  'Services',
    footer_contact:   'Contact',
    footer_addr: '40100 Marrakech, Morocco',
    footer_phone:     '+212 069 372 1314',
    footer_email:     'amourkira216@gmail.com',
    footer_copy:      '© 2026 28ink-tattoos Marrakech. All rights reserved.',
    footer_legal_privacy: 'Privacy',
    footer_legal_terms:   'Legal',

    /* SERVICES */
    services_hero_label: 'Our Services',
    services_hero_title: 'Services tailored to your vision',
    services_hero_desc:  'From your first tattoo to the most ambitious project, we guide you every step of the way.',
    services: [
      { icon:'needle', title:'Fine Line Tattoo', desc:'Ultra-thin lines, chiselled details. Our signature for delicate and timeless compositions.' },
      { icon:'geometry', title:'Geometric Tattoo', desc:'Perfect symmetries, mandalas, mathematical lines. Artistic precision our clients love.' },
      { icon:'flower', title:'Floral & Botanical', desc:'Roses, leaves, floral compositions — natural and elegant on any body area.' },
      { icon:'text', title:'Script & Lettering', desc:'Quotes, names, Arabic or Latin calligraphy. Every letter worn with intention.' },
      { icon:'blackwork', title:'Blackwork & Dotwork', desc:'Strong contrasts, dot-fill shading. A powerful style for radical expression.' },
      { icon:'cover', title:'Touch-up & Cover-up', desc:'Redesign or correction of an existing tattoo. Our artists analyse and propose the best solution.' },
      { icon:'consult', title:'Project discussion', desc:'Discuss your project with our artists. Custom design included before every session.' },
      { icon:'aftercare', title:'Aftercare & Follow-up', desc:'We provide full post-tattoo care advice for optimal healing.' }
    ],

    /* GALLERY */
    gallery_hero_label: 'Portfolio',
    gallery_hero_title: 'Every tattoo, a masterpiece',
    gallery_hero_desc:  'Browse all our work. Photos and process videos included.',
    gallery_filter_all:       'All',
    gallery_filter_photo:     'Photos',
    gallery_filter_video:     'Videos',
    gallery_filter_fineline:  'Fineline',
    gallery_filter_geometric: 'Geometric',
    gallery_filter_floral:    'Floral',
    gallery_filter_blackwork: 'Blackwork',

    /* CONTACT */
    contact_hero_label: 'Contact',
    contact_hero_title: 'Let\'s talk about your project',
    contact_hero_desc:  'Fill in the form or contact us directly on WhatsApp.',
    contact_name:    'Full name',
    contact_email:   'Email',
    contact_phone:   'Phone (optional)',
    contact_style:   'Desired style',
    contact_message: 'Describe your project',
    contact_send:    'Send via WhatsApp',
    contact_wa_direct: 'WhatsApp Direct',
    contact_address: 'Address',
    contact_hours:   'Opening hours',
        contact_sunday:  'Closed on Sundays',
    select_style:    'Select a style',

    /* FAQ */
    faq_hero_label: 'FAQ',
    faq_hero_title: 'Everything you need to know',
    faq_hero_desc:  'Clear answers about tattooing, booking and aftercare.',
    faqs: [
      { q:'How do I book a session at 28INK?', a:'Contact us via WhatsApp at +212 069 372 1314 or via our contact form to discuss your project.' },
      { q:'How can I discuss my tattoo project?', a:'Message us on WhatsApp with your idea, approximate placement and size to discuss the details.' },
      { q:'Is your equipment sterilised and safe?', a:'Absolutely. We use single-use needles exclusively. Our equipment is sterilised to international standards. Hygiene is our top priority.' },
      { q:'How long does a tattoo take to heal?', a:'Surface healing takes 2–3 weeks. Deep healing takes 3–6 months. We provide a full aftercare guide after every session.' },
      { q:'Can I bring my own design?', a:'Yes, absolutely! You can bring a reference or drawing. Our artists adapt it to your skin and improve the design if needed.' },
      { q:'Do you do touch-ups and cover-ups?', a:'Yes. We analyse each case and propose the best technical solution. A prior consultation is needed for complex cover-ups.' },
      { q:'Is the initial consultation free?', a:'Yes, consultation is completely free. Discuss your project with our artists with no commitment.' },
      { q:'Do you tattoo tourists visiting Marrakech?', a:'Yes, we welcome all clients, tourists and residents alike. Simply book in advance to secure your slot.' },
      { q:'What is the exact address of the studio?', a:'Our studio is located in the Medina of Marrakech. Contact us on WhatsApp for the precise address and directions.' },
      { q:'Do you offer temporary tattoos?', a:'No, we specialise exclusively in professional-quality permanent tattooing.' }
    ],

    /* BLOG */
    blog_hero_label: 'Blog & News',
    blog_hero_title: 'Art, Culture & Ink',
    blog_hero_desc:  'Tips, inspiration and behind-the-scenes from 28INK Marrakech studio.',

    /* CHATBOT */
    chatbot_name:    '28INK Assistant',
    chatbot_status:  'Online now',
    chatbot_welcome: 'Hello! 👋 I\'m the 28INK Marrakech assistant. How can I help you?',
    chatbot_price:   'Message the studio on WhatsApp with your idea and preferred placement to discuss your project.',
    chatbot_book:    'To discuss your project, contact the studio on WhatsApp at +212 069 372 1314.',
    chatbot_hygiene: 'We use single-use needles and our equipment is sterilised to international standards.',
    chatbot_heist:   'The studio is listed in 40100 Marrakech. Find the supplied map pin and directions on the Contact page.',
    chatbot_fallback:'I don\'t have that specific information. Contact us directly on WhatsApp for an immediate reply!',
    chatbot_wa:      'Message on WhatsApp',
    chatbot_quick_price:    '💬 Project',
    chatbot_quick_book:     '📅 Book',
    chatbot_quick_hygiene:  '🧼 Hygiene',
    chatbot_quick_location: '📍 Location',
    chatbot_placeholder: 'Ask your question...',
  },

  /* ─── ITALIANO ──────────────────────────────────────────── */
  it: {
    /* NAV */
    nav_home:          'Home',
    nav_services:      'Servizi',
    nav_gallery:       'Galleria',
    nav_about:         'Chi Siamo',
    nav_blog:          'Blog',
    nav_faq:           'FAQ',
    nav_contact:       'Contatti',
    nav_book:          'Prenota',

    /* HERO */
    hero_kicker:       'Studio di Tatuaggi — Marrakech, Marocco',
    hero_title_1:      '28ink-tattoos',
    hero_title_2:      'Marrakech',
    hero_subtitle:     'Arte permanente, tradizione marocchina. Il primo studio di tatuaggi premium di Marrakech.',
    hero_btn_gallery:  'Vedi la Galleria',
    hero_btn_book:     'Prenota Ora',

    /* TICKER */
    ticker_1: 'Fine Line', ticker_2: 'Minimalista', ticker_3: 'Geometrico',
    ticker_4: 'Floreale', ticker_5: 'Realistico', ticker_6: 'Orientale',
    ticker_7: 'Script', ticker_8: 'Blackwork', ticker_9: 'Marrakech',

    /* ABOUT */
    about_label:       'La Nostra Storia',
    about_title:       'L\'arte del tatuaggio nel cuore della Medina',
    about_desc:        '28ink-tattoos è studio di tatuaggi a Marrakech, fondato da Adam Mehdi. Fondiamo l\'arte contemporanea con il patrimonio culturale marocchino per creare opere permanenti d\'eccezione.',
    about_since:       'Dal 2018',
    about_stat1_num:   '01', about_stat1_lbl: 'Studio · Marrakech',
    about_stat2_num:   '3',    about_stat2_lbl: 'Artisti Esperti',
    about_stat3_num:   '98%',  about_stat3_lbl: 'Tasso di Soddisfazione',

    /* STYLES */
    styles_label:      'Le Nostre Specialità',
    styles_title:      'Ogni stile, una firma',
    style1_title:      'Fine & Minimalista',    style1_sub: 'Fineline · Delicato',
    style2_title:      'Geometrico',            style2_sub: 'Simmetria · Precisione',
    style3_title:      'Floreale & Botanico',   style3_sub: 'Natura · Eleganza',
    style4_title:      'Script & Lettering',    style4_sub: 'Scrittura · Significato',
    style5_title:      'Blackwork',             style5_sub: 'Contrasto · Impatto',
    style6_title:      'Orientale & Arabesco',  style6_sub: 'Cultura · Tradizione',

    /* REEL */
    reel_label: 'In Azione',
    reel_title: 'Il processo creativo',
    reel_desc:  'Guarda i nostri tatuatori al lavoro. Ogni gesto è preciso, ogni tratto è definitivo.',

    /* STATS */
    stat1_num: '01', stat1_lbl: 'Creazione su misura',
    stat2_num: '6',   stat2_lbl: 'Anni di Esperienza',
    stat3_num: '100', stat3_lbl: 'Design Esclusivi',
    stat4_num: '3',   stat4_lbl: 'Stili del portfolio',

    /* BOOK CTA */
    book_label: 'Prenotazione',
    book_title: 'Pronto/a a portare la tua storia sulla pelle?',
    book_desc:  'Scrivici su WhatsApp per parlare del tuo progetto e dei prossimi passi.',
    book_btn:   'Prenota su WhatsApp',
    book_or:    'oppure',
    book_form:  'Modulo di Contatto',

    /* FOOTER */
    footer_tagline:   'Studio di tatuaggi e disegni personalizzati a Marrakech, Marocco.',
    footer_nav:       'Navigazione',
    footer_services:  'Servizi',
    footer_contact:   'Contatti',
    footer_addr:      '40100 Marrakech, Marocco',
        footer_phone:     '+212 069 372 1314',
    footer_email:     'amourkira216@gmail.com',
    footer_copy:      '© 2026 28ink-tattoos Marrakech. Tutti i diritti riservati.',
    footer_legal_privacy: 'Privacy',
    footer_legal_terms:   'Note Legali',

    /* SERVICES */
    services_hero_label: 'I Nostri Servizi',
    services_hero_title: 'Servizi su misura per la tua visione',
    services_hero_desc:  'Dal primo tatuaggio al progetto più ambizioso, vi accompagniamo in ogni fase.',
    services: [
      { icon:'needle', title:'Tatuaggio Fine Line', desc:'Linee ultra-sottili, dettagli cesellati. La nostra specialità per composizioni delicate e senza tempo.' },
      { icon:'geometry', title:'Tatuaggio Geometrico', desc:'Simmetrie perfette, mandala, linee matematiche. La rigore artistico che i nostri clienti amano.' },
      { icon:'flower', title:'Floreale & Botanico', desc:'Rose, foglie, composizioni floreali — naturali ed eleganti su tutte le zone del corpo.' },
      { icon:'text', title:'Script & Lettering', desc:'Citazioni, nomi, calligrafia araba o latina. Ogni lettera portata con intenzione.' },
      { icon:'blackwork', title:'Blackwork & Dotwork', desc:'Contrasti potenti, riempimenti a puntini. Uno stile forte per un\'espressione radicale.' },
      { icon:'cover', title:'Ritocco & Cover-up', desc:'Rifacimento o correzione di un vecchio tatuaggio. I nostri artisti analizzano e propongono la migliore soluzione.' },
      { icon:'consult', title:'Scambio sul progetto', desc:'Discutete il vostro progetto con i nostri artisti. Design personalizzato incluso prima di ogni sessione.' },
      { icon:'aftercare', title:'Cura & Follow-up', desc:'Forniamo tutti i consigli post-tatuaggio per una cicatrizzazione ottimale.' }
    ],

    /* GALLERY */
    gallery_hero_label: 'Portfolio',
    gallery_hero_title: 'Ogni tatuaggio, un\'opera d\'arte',
    gallery_hero_desc:  'Esplora tutte le nostre realizzazioni. Foto e video del processo inclusi.',
    gallery_filter_all:       'Tutto',
    gallery_filter_photo:     'Foto',
    gallery_filter_video:     'Video',
    gallery_filter_fineline:  'Fineline',
    gallery_filter_geometric: 'Geometrico',
    gallery_filter_floral:    'Floreale',
    gallery_filter_blackwork: 'Blackwork',

    /* CONTACT */
    contact_hero_label: 'Contatti',
    contact_hero_title: 'Parliamo del tuo progetto',
    contact_hero_desc:  'Compila il modulo o contattaci direttamente su WhatsApp.',
    contact_name:    'Nome completo',
    contact_email:   'Email',
    contact_phone:   'Telefono (opzionale)',
    contact_style:   'Stile desiderato',
    contact_message: 'Descrivi il tuo progetto',
    contact_send:    'Invia su WhatsApp',
    contact_wa_direct: 'WhatsApp Diretto',
    contact_address: 'Indirizzo',
    contact_hours:   'Orari',
        contact_sunday:  'Chiuso la domenica',
    select_style:    'Seleziona uno stile',

    /* FAQ */
    faq_hero_label: 'Domande Frequenti',
    faq_hero_title: 'Tutto ciò che devi sapere',
    faq_hero_desc:  'Risposte chiare sul tatuaggio, la prenotazione e le cure post-tattoo.',
    faqs: [
      { q:'Come si prenota una sessione da 28ink-tattoos?', a:'Contattateci via WhatsApp al +212 069 372 1314 o tramite il nostro modulo di contatto. Di solito rispondiamo entro un\'ora durante l\'orario di apertura.' },
      { q:'Come posso parlare del mio progetto di tatuaggio?', a:'Scrivici su WhatsApp descrivendo l’idea, la posizione e le dimensioni approssimative. Lo studio ti risponderà direttamente per discutere i dettagli.' },
      { q:'La vostra attrezzatura è sterilizzata e sicura?', a:'Assolutamente. Utilizziamo esclusivamente aghi monouso. La nostra attrezzatura è sterilizzata secondo gli standard internazionali. L\'igiene è la nostra priorità assoluta.' },
      { q:'Quanto tempo richiede la cicatrizzazione di un tatuaggio?', a:'La cicatrizzazione superficiale richiede 2-3 settimane. Quella profonda dura 3-6 mesi. Forniamo una guida completa per la cura dopo ogni sessione.' },
      { q:'Posso portare il mio disegno?', a:'Sì, assolutamente! Potete portare un riferimento o un disegno. I nostri artisti lo adattano alla vostra pelle e migliorano il design se necessario.' },
      { q:'Eseguite ritocchi e cover-up?', a:'Sì. Analizziamo ogni caso e proponiamo la migliore soluzione tecnica. Una consulenza preventiva è necessaria per cover-up complessi.' },
      { q:'Come parlare del mio progetto?', a:'Scrivi allo studio su WhatsApp con la tua idea, la posizione e le dimensioni approssimative.' },
      { q:'Fate tatuaggi ai turisti in visita a Marrakech?', a:'Sì, accogliamo tutti i clienti, turisti e residenti. Prenotate semplicemente in anticipo per garantire il vostro posto.' },
      { q:'Qual è l\'indirizzo esatto dello studio?', a:'Il nostro studio si trova nella Medina di Marrakech. Contattateci su WhatsApp per l\'indirizzo preciso e le indicazioni stradali.' },
      { q:'Offrite tatuaggi temporanei?', a:'No, ci specializziamo esclusivamente nel tatuaggio permanente di qualità professionale.' }
    ],

    /* BLOG */
    blog_hero_label: 'Blog & Notizie',
    blog_hero_title: 'Arte, Cultura & Inchiostro',
    blog_hero_desc:  'Consigli, ispirazioni e retroscena dallo studio 28ink-tattoos Marrakech.',

    /* CHATBOT */
    chatbot_name:    '28ink-tattoos Assistente',
    chatbot_status:  'Online ora',
    chatbot_welcome: 'Ciao! 👋 Sono l\'assistente di 28ink-tattoos Marrakech. Come posso aiutarti?',
    chatbot_price:   'Scrivi allo studio su WhatsApp con la tua idea e la posizione desiderata per discutere il progetto.',
    chatbot_book:    'Per prenotare, contattateci su WhatsApp: +212 069 372 1314 o tramite il nostro modulo di contatto.',
    chatbot_hygiene: 'Utilizziamo aghi monouso e la nostra attrezzatura è sterilizzata secondo gli standard internazionali.',
    chatbot_heist:   'Il nostro studio si trova nella Medina di Marrakech. Contattateci per l\'indirizzo esatto.',
    chatbot_fallback:'Non ho questa informazione precisa. Contattateci direttamente su WhatsApp per una risposta immediata!',
    chatbot_wa:      'Scrivi su WhatsApp',
    chatbot_quick_price:    '💬 Il mio progetto',
    chatbot_quick_book:     '📅 Prenota',
    chatbot_quick_hygiene:  '🧼 Igiene',
    chatbot_quick_location: '📍 Indirizzo',
    chatbot_placeholder: 'Fai la tua domanda...',
  }
};

/* ── i18n Engine ─────────────────────────────────────────── */
const pathParts = location.pathname.split('/').filter(Boolean);
const routeLang = ['en', 'it'].includes(pathParts[0]) ? pathParts[0] : 'fr';
let currentLang = routeLang;

function t(key) {
  const lang = translations[currentLang] || translations.fr;
  return lang[key] !== undefined ? lang[key] : (translations.fr[key] || key);
}

const pageTextMap = window.PAGE_TRANSLATIONS || {};
const reverseTextMap = { en: new Map(), it: new Map() };
Object.entries(pageTextMap).forEach(([source, versions]) => {
  ['en', 'it'].forEach(locale => {
    const translated = String(versions[locale] ?? '').replace(/\s+/g, ' ').trim();
    if (!translated) return;
    const candidates = reverseTextMap[locale].get(translated) || [];
    candidates.push(source);
    reverseTextMap[locale].set(translated, candidates);
  });
});

function normaliseText(value) { return String(value ?? '').replace(/\s+/g, ' ').trim(); }

function sourceTextFor(locale, value) {
  const normalized = normaliseText(value);
  if (locale === 'fr') return normalized;
  return reverseTextMap[locale]?.get(normalized)?.[0] || null;
}

function localizedValue(value, targetLocale) {
  const source = sourceTextFor(currentLang, value);
  if (targetLocale === 'fr') return source;
  return source && pageTextMap[source] ? pageTextMap[source][targetLocale] : null;
}

function translatePageContent(targetLocale) {
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const textNodes = [];
  while (walker.nextNode()) textNodes.push(walker.currentNode);
  textNodes.forEach(node => {
    const parent = node.parentElement;
    if (!parent || parent.closest('script,style,noscript,svg')) return;
    const oldValue = node.nodeValue || '';
    const normalized = normaliseText(oldValue);
    if (!normalized || /^[\d\W_]+$/.test(normalized)) return;
    const replacement = localizedValue(normalized, targetLocale);
    if (replacement == null) return;
    const leading = oldValue.match(/^\s*/)?.[0] || '';
    const trailing = oldValue.match(/\s*$/)?.[0] || '';
    node.nodeValue = leading + replacement + trailing;
  });

  const translatableAttributes = ['alt', 'title', 'aria-label', 'placeholder', 'value'];
  document.querySelectorAll('body *').forEach(el => translatableAttributes.forEach(attribute => {
    const value = el.getAttribute(attribute);
    if (!value) return;
    const replacement = localizedValue(value, targetLocale);
    if (replacement != null) el.setAttribute(attribute, replacement);
  }));
}

const headingOverrides = {
  contact_title: {
    fr: 'Réservez votre <em>rendez-vous</em>',
    en: 'Book your <em>appointment</em>',
    it: 'Prenota il tuo <em>appuntamento</em>'
  },
  faq_title: {
    fr: 'Vos <em>questions</em>, nos réponses',
    en: 'Your <em>questions</em>, our answers',
    it: 'Le tue <em>domande</em>, le nostre risposte'
  },
  gal_title: {
    fr: 'Nos <em>réalisations</em>',
    en: 'Our <em>portfolio</em>',
    it: 'Il nostro <em>portfolio</em>'
  }
};

function applyHeadingOverrides(locale) {
  Object.entries(headingOverrides).forEach(([key, versions]) => {
    const heading = document.querySelector(`[data-i18n="${key}"]`);
    if (heading) heading.innerHTML = versions[locale];
  });
}

function pageFilename() {
  const parts = location.pathname.split('/').filter(Boolean);
  if (parts[0] === 'en' || parts[0] === 'it') parts.shift();
  return parts.length ? parts[parts.length - 1] : 'index.html';
}

function updateLocalizedMetadata(locale) {
  const meta = window.PAGE_META?.[pageFilename()]?.[locale];
  if (!meta) return;
  document.documentElement.lang = locale;
  document.title = meta.title;
  const values = [
    ['meta[name="description"]', meta.description],
    ['meta[name="keywords"]', meta.keywords],
    ['meta[property="og:title"]', meta.title],
    ['meta[property="og:description"]', meta.description],
    ['meta[property="og:url"]', meta.url],
    ['meta[property="og:image"]', meta.image],
    ['meta[name="twitter:title"]', meta.title],
    ['meta[name="twitter:description"]', meta.description],
    ['meta[name="twitter:image"]', meta.image]
  ];
  values.forEach(([selector, content]) => {
    const el = document.querySelector(selector);
    if (el && content != null) el.setAttribute('content', content);
  });
  const canonical = document.querySelector('link[rel="canonical"]');
  if (canonical && meta.canonical) canonical.href = meta.canonical;
}

function localizeInternalLinks(locale) {
  document.querySelectorAll('a[href^="/"]').forEach(anchor => {
    const url = new URL(anchor.getAttribute('href'), location.origin);
    if (url.origin !== location.origin) return;
    let path = url.pathname.replace(/^\/(en|it)(?=\/)/, '');
    if (path === '/en' || path === '/it') path = '/';
    if (path !== '/' && !path.endsWith('.html')) return;
    const prefix = locale === 'fr' ? '' : `/${locale}`;
    anchor.setAttribute('href', `${prefix}${path === '/' ? '/' : path}${url.search}${url.hash}`);
  });
}

function applyTranslations() {
  const lang = translations[currentLang] || translations.fr;
  document.documentElement.lang = currentLang;
  // The page body is statically localized for crawlers; translate only shared UI.
  document.querySelectorAll('#nav [data-i18n], #navDrawer [data-i18n], #footer [data-i18n], #cb-window [data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (typeof lang[key] === 'string') el.textContent = lang[key];
  });
  document.querySelectorAll('#cb-window [data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (lang[key]) el.placeholder = lang[key];
  });
  document.querySelectorAll('.lang-btn').forEach(btn => {
    const active = btn.dataset.lang === currentLang;
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-pressed', active ? 'true' : 'false');
  });
  const labels = {
    fr: { nav:'Navigation principale', menu:'Ouvrir le menu', close:'Fermer le menu', menuOpenText:'MENU', menuCloseText:'FERMER', language:'Langue', drawer:'Menu mobile', chatbot:'Ouvrir le chat 28ink-tattoos', lb:'Visionneuse d’images', prev:'Précédent', next:'Suivant', chatClose:'Fermer le chat', send:'Envoyer' },
    en: { nav:'Main navigation', menu:'Open menu', close:'Close menu', menuOpenText:'MENU', menuCloseText:'CLOSE', language:'Language', drawer:'Mobile menu', chatbot:'Open 28ink-tattoos chat', lb:'Image viewer', prev:'Previous', next:'Next', chatClose:'Close chat', send:'Send' },
    it: { nav:'Navigazione principale', menu:'Apri il menu', close:'Chiudi il menu', menuOpenText:'MENU', menuCloseText:'CHIUDI', language:'Lingua', drawer:'Menu mobile', chatbot:'Apri la chat 28ink-tattoos', lb:'Visualizzatore immagini', prev:'Precedente', next:'Successivo', chatClose:'Chiudi la chat', send:'Invia' }
  }[currentLang];
  document.querySelector('#nav')?.setAttribute('aria-label', labels.nav);
  const burger = document.querySelector('#navBurger');
  burger?.setAttribute('aria-label', labels.menu);
  burger?.setAttribute('data-menu-label', burger.classList.contains('open') ? labels.menuCloseText : labels.menuOpenText);
  document.querySelector('#navDrawer')?.setAttribute('aria-label', labels.drawer);
  document.querySelector('.drawer-close')?.setAttribute('aria-label', labels.close);
  document.querySelector('.lang-sw')?.setAttribute('aria-label', labels.language);
  document.querySelector('#cb-toggle')?.setAttribute('aria-label', labels.chatbot);
  document.querySelector('.cb-close')?.setAttribute('aria-label', labels.chatClose);
  document.querySelector('#chatbotSend')?.setAttribute('aria-label', labels.send);
  document.querySelector('#lightbox')?.setAttribute('aria-label', labels.lb);
  document.querySelector('.lb-close')?.setAttribute('aria-label', labels.close);
  document.querySelector('.lb-prev')?.setAttribute('aria-label', labels.prev);
  document.querySelector('.lb-next')?.setAttribute('aria-label', labels.next);
  document.dispatchEvent(new CustomEvent('i18n:applied', { detail: { lang: currentLang, t: lang } }));
}

function setLang(lang) {
  if (!translations[lang]) return;
  if (lang === currentLang) {
    applyTranslations();
    return;
  }
  translatePageContent(lang);
  applyHeadingOverrides(lang);
  currentLang = lang;
  try { localStorage.setItem('28ink_lang', lang); } catch (_) {}
  const parts = location.pathname.split('/').filter(Boolean);
  if (parts[0] === 'en' || parts[0] === 'it') parts.shift();
  const file = parts.length ? parts.join('/') : 'index.html';
  const pagePath = file === 'index.html' ? '/' : `/${file}`;
  const nextPath = lang === 'fr' ? pagePath : `/${lang}${pagePath}`;
  if (nextPath !== location.pathname) history.pushState({ lang }, '', nextPath + location.search + location.hash);
  document.getElementById('navDrawer')?.classList.remove('open');
  document.getElementById('navBurger')?.classList.remove('open');
  document.getElementById('navBurger')?.setAttribute('aria-expanded', 'false');
  document.body.style.overflow = '';
  updateLocalizedMetadata(lang);
  localizeInternalLinks(lang);
  applyTranslations();
}

document.addEventListener('click', event => {
  const button = event.target.closest('.lang-btn');
  if (button) setLang(button.dataset.lang);
});
window.addEventListener('popstate', () => {
  const parts = location.pathname.split('/').filter(Boolean);
  const lang = ['en', 'it'].includes(parts[0]) ? parts[0] : 'fr';
  if (lang !== currentLang) setLang(lang, false);
});
document.addEventListener('DOMContentLoaded', () => setTimeout(applyTranslations, 0));
window.i18n = { t, setLang, applyTranslations, currentLang: () => currentLang, translations };
